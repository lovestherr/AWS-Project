import json
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import NoCredentialsError, ClientError
import base64

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Course')

s3 = boto3.client('s3')

# AWS S3 Bucket name
bucket_name = 'yyeproject'

def create(event, context):
    if event['httpMethod'] == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': ''
        }

    # Parse the input
    body = json.loads(event['body'])
    
    course_id = body['CourseID']
    course_name = body['CourseName']
    course_description = body['CourseDescription']
    content_path = body['ContentPath']

    # Get file content and decode it from base64
    file_content_base64 = body['FileContent']
    file_content = base64.b64decode(file_content_base64)
    
    # Define S3 bucket and object name
    object_name = f'uploads/{course_id}/{course_name}.txt'
    
    # Upload file to S3
    success, message = upload_file(file_content, bucket_name, object_name)
    
    if not success:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true'
            },
            'body': json.dumps(f"Failed to upload file: {message}")
        }
    
    # Put the item into DynamoDB
    response = table.put_item(
        Item={
            'CourseID': course_id,
            'CourseName': course_name,
            'CourseDescription': course_description,
            'ContentPath': content_path,
        }
    )
    
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        'body': json.dumps('Course created successfully')
    }

def upload_file(file_content, bucket_name, object_name, region_name='eu-west-1'):
    try:
        s3.put_object(Bucket=bucket_name, Key=object_name, Body=file_content)
    except NoCredentialsError:
        return False, "Credentials not available"
    except ClientError as e:
        return False, str(e)
    return True, "File uploaded successfully"
